#!/bin/sh
v2ray -config=/etc/v2ray/config.json
